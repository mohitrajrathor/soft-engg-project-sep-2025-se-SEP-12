# AURA Backend

This document provides instructions for setting up and running the AURA backend server. For complete project documentation, please see the `README.md` file in the root directory.

## Prerequisites

- Python 3.11+
- Git

## Setup and Installation

1.  **Navigate to the backend directory:**
    If you are in the project root, you should already be in the correct parent directory. The commands below should be run from within this `backend` folder.

2.  **Create and activate a virtual environment:**

    -   On Windows:
        ```bash
        python -m venv .venv
        .venv\Scripts\activate
        ```

    -   On macOS/Linux:
        ```bash
        python3 -m venv .venv
        source .venv/bin/activate
        ```

3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Configure Environment Variables:**
    Create a `.env` file in this `backend` directory. You can copy the contents below as a starting point.

    ```bash
    # Application Settings
    APP_NAME=AURA
    APP_VERSION=1.0.0
    DEBUG=true

    # Database Configuration (SQLite default)
    DATABASE_URL=sqlite:///./app.db

    # JWT Security
    SECRET_KEY=your-secret-key-here-minimum-32-characters-long
    ALGORITHM=HS256
    ACCESS_TOKEN_EXPIRE_MINUTES=60
    REFRESH_TOKEN_EXPIRE_DAYS=7

    # CORS Configuration for frontend
    CORS_ORIGINS=["http://localhost:5173"]
    CORS_ALLOW_CREDENTIALS=true
    CORS_ALLOW_METHODS=["*"]
    CORS_ALLOW_HEADERS=["*"]

    # Google Gemini AI Configuration
    GOOGLE_API_KEY=your-gemini-api-key-here
    ```
    **Important:** You must provide your own `SECRET_KEY` and `GOOGLE_API_KEY`.

## Running the Server

Once the setup is complete, you can run the development server:

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The `--reload` flag enables auto-reloading when you make changes to the code.

## Accessing the API

The backend server will be available at `http://localhost:8000`.

-   **Swagger UI (Interactive Docs):** http://localhost:8000/docs
-   **ReDoc (Alternative Docs):** http://localhost:8000/redoc